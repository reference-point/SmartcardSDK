package uk.co.referencepoint.smartcardsdksampleapp

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.nfc.NfcAdapter
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import uk.co.referencepoint.android.smartcard.sdk.SmartcardClient
import uk.co.referencepoint.android.smartcard.sdk.client.*
import uk.co.referencepoint.android.smartcard.sdk.common.CardData
import uk.co.referencepoint.android.smartcard.sdk.enums.enumSyncOption
import uk.co.referencepoint.android.smartcard.sdk.helpers.Helpers
import uk.co.referencepoint.android.smartcard.sdk.metadata.cscs.CSCSMetadata
import uk.co.referencepoint.android.smartcard.sdk.render.CardRenderRoundingBorder
import uk.co.referencepoint.android.smartcard.sdk.render.CardRenderRoundingParams
import java.util.*

class MainActivity : AppCompatActivity() {

    // NFC
    private var pendingIntent: PendingIntent? = null
    private var techListsArray: Array<Array<String>>? = null
    private var intentFiltersArray: Array<IntentFilter>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initSDK()
        initNFC()

        // device is now ready to read a card using NFC...
    }

    override fun onResume() {
        super.onResume()
        activateNFC()
    }

    @SuppressLint("MissingSuperCall")
    override fun onNewIntent(intent: Intent) {

        addProgress("NFC intent received.")

        val action = intent.action
        if (NfcAdapter.ACTION_TAG_DISCOVERED == action || NfcAdapter.ACTION_TECH_DISCOVERED == action) {
            readCard(intent)
        }
    }


    private fun initSDK() {


        // ******************************************************************
        // ADD YOUR VALUES HERE otherwise the SDK will fail initialisation...
        // ******************************************************************

        val apiKey = "your-api-key"
        val appIdentifierName = "your-app-identifier-name"
        val appVersion = "1.0.0"
        val friendlyName = "your-friendly-app-name"

        SmartcardClient.init(
            this.applicationContext,
            object : ISmartcardClientEventHandler<InitTaskResult> {
                override fun onProgressUpdate(s: String) {
                    addProgress(s)
                }

                @SuppressLint("DefaultLocale")
                override fun onPostExecute(smartcardClientResult: SmartcardClientResult<InitTaskResult>) {

                    if (smartcardClientResult.isSuccess) {
                        addProgress("SDK has been successfully initialised\nTo read a card, hold it to the back of the device")
                    } else
                        addProgress("SDK initialisation failed with the following error:\n\n${smartcardClientResult.error.fullErrorMessage}")
                }
            },
            InitTaskParams(apiKey, appIdentifierName, appVersion, friendlyName)
        )
    }

    private fun initNFC() {
        val intent = Intent(this, this.javaClass)
        intent.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        pendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        val ndef = IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED)
        try {
            ndef.addDataType("*/*")
        } catch (e: IntentFilter.MalformedMimeTypeException) {
            throw RuntimeException("fail", e)
        }

        intentFiltersArray = arrayOf(ndef)
        techListsArray = arrayOf(arrayOf(android.nfc.tech.IsoDep::class.java.name))
    }

    internal fun addProgress(msg: String?) {

        if (msg != null)
            initProgress.text = "${initProgress.text} $msg\n"
    }

    private fun activateNFC() {
        val mAdapter = NfcAdapter.getDefaultAdapter(this)
        mAdapter.enableForegroundDispatch(
            this,
            pendingIntent,
            intentFiltersArray,
            techListsArray
        )
    }


    private fun readCard(intent: Intent) {
        addProgress("Reading card...")

        cardImageFront.setImageBitmap(null)
        cardImageBack.setImageBitmap(null)

        //val sync = enumSyncOption.SYNC        // writes the latest data from the server to the card first
        val sync = enumSyncOption.NO_SYNC       // offline read - displays whatever is currently on the card
        SmartcardClient.readCard(
            applicationContext,
            object : ISmartcardClientEventHandler<ReadCardTaskResult> {

                override fun onPostExecute(result: SmartcardClientResult<ReadCardTaskResult>?) {
                    handleReadCardResponse(result, sync)
                }

                override fun onProgressUpdate(progressMsg: String?) {
                    addProgress(progressMsg)
                }
            },
            intent,
            sync
        )
    }

    private fun handleReadCardResponse(result: SmartcardClientResult<ReadCardTaskResult>?, syncOption: enumSyncOption) {

        if (result == null) {
            addProgress("SDK returned a null card data result")
            return
        }

        if (!result.isSuccess) {
            var msg = "Read failed - "
            val e = result.error
            if (e != null) {
                msg += e.fullErrorMessage
            }
            addProgress(msg)
            return
        }

        val cardData = result.result.cardData
        if (syncOption == enumSyncOption.SYNC_ONLY) {
            return
        }
        if (cardData == null) {
            addProgress("ERROR: Card data is null.")
            return
        }
        renderCard(cardData)
    }

    private fun renderCard(cardData: CardData) {

        addProgress("Drawing the card...")

        val metaData = CSCSMetadata()
        val hashMap: HashMap<String, String>?
        try {
            hashMap = metaData.getRenderData(cardData)
        } catch (e: Exception) {
            addProgress("Card render request failed with following exception: ${e.message}")
            return
        }

        if (hashMap == null) {
            addProgress(String.format("Card render request failed. Unable to create hashmap."))
            return
        }
        drawCard(cardData, hashMap)
    }

    private fun drawCard(cardData: CardData, hashMap: HashMap<String, String>?) {

        val roundingBorder = CardRenderRoundingBorder(Color.BLUE, 1)
        val rounding = CardRenderRoundingParams(12, Color.WHITE, roundingBorder, roundingBorder)

        SmartcardClient.renderCard(
            applicationContext,
            object : ISmartcardClientEventHandler<RenderCardTaskResult> {
                override fun onProgressUpdate(progressMsg: String) {
                    addProgress(progressMsg)
                }

                override fun onPostExecute(result: SmartcardClientResult<RenderCardTaskResult>) {

                    if (!result.isSuccess) {
                        addProgress(
                            Helpers.getSmartcardClientResultErrMsg(
                                result,
                                "Unable to render the card."
                            )
                        )
                        return
                    }
                    displayCard(result.result)
                }
            },
            RenderCardTaskParams(cardData.scheme.identifier, hashMap, rounding)
        )
    }

    private fun displayCard(renderResult: RenderCardTaskResult) {

        if (renderResult.cardFront == null) {
            addProgress("Card render bitmap is null")
            return
        }

        addProgress("Card render request successful...")

        cardImageFront.setImageBitmap(renderResult.cardFront)
        cardImageBack.setImageBitmap(renderResult.cardBack)

        activateNFC()
    }
}

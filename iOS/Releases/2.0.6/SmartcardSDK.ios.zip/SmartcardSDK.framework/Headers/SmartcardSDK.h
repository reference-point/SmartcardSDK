//
//  SmartcardSDK.h
//  SmartcardSDK
//
//  Created by Jianbang Li on 04/10/2017.
//  Copyright © 2017 Jianbang Li. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SmartcardSDK.
FOUNDATION_EXPORT double SmartcardSDKVersionNumber;

//! Project version string for SmartcardSDK.
FOUNDATION_EXPORT const unsigned char SmartcardSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmartcardSDK/PublicHeader.h>


